from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .forms import UserRegisterForm, ExampleForms, UserUpdateForm, ProfileUpdateForm
from django.core.mail  import send_mail
from django.conf import settings
# Create your views here.
from django.contrib.auth.decorators import login_required
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            email = form.cleaned_data.get('email')
            subject = f'WELCOME, {username}'
            message = '''Welcome to StarLike Vehicle Pooling ..!
            StarLike is a platform wherein the students of our college can share rides to and fro college. Starlike is aimed at reducing problems encountered by students and bring their lives at ease. You can share your journey to college with your buddies..! You can connect with students of various departments and stay updated..! This software will help you to collaborate with many students..! READY TO LEVEL UP? Fix a ride to college..!'''
            from_email = settings.EMAIL_HOST_USER
            to_list = [email, settings.EMAIL_HOST_USER]
            send_mail(subject, message, from_email, to_list, fail_silently = True)


            messages.success(request, f'Account created for {username}! You can now login.')
            return redirect('blog-home')
    else:
        form = UserRegisterForm()
    return render(request, 'users/register.html', {'form':form})
def example(request):
    form = ExampleForms()
    return render(request, 'users/example.html', {'form':form})
@login_required
def profile(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST,
                                   request.FILES,
                                   instance=request.user.profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, f'Your account has been updated!')
            return redirect('profile')

    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'u_form': u_form,
        'p_form': p_form
    }

    return render(request, 'users/profile.html', context)