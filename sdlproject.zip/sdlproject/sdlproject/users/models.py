from django.db import models
from django.contrib.auth.models import User
import datetime
from PIL import Image
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete = models.CASCADE)
    branch = models.IntegerField(default = 1, choices = ((1, ("Computer")),(2, ("Electronics and TeleCommunication")),(3, ("Electrical")),(4, ("Mechanical")),(5, ("Civil")),(6, ("Automobile"))))
    phone_no = models.CharField(blank = True, null = False, max_length = 12)
    year_of_study = models.IntegerField(default = 1, choices = ((1, ("Ist")),(2, ("IInd")),(3, ("IIIrd")),(4, ("IVth"))))
    date_of_birth = models.DateField(default = datetime.date.today)
    has_driving_license = models.IntegerField(default = 2, choices = ((1, ("Yes")),(2, ("No"))))
    class_division = models.IntegerField(default = 1, choices = ((1, ("A")),(2, ("B")), (3, ("C"))))
    two_wheeler_no = models.CharField(blank = True, null = False, max_length = 10)
    four_wheeler_no = models.CharField(blank = True, null = False, max_length = 10)
    gender = models.IntegerField(default = 3, choices = ((1, ("Female")),(2, ("Male")),(3, ("Not Disclose"))))
    locality = models.CharField(blank = True, null = False, max_length = 150)
    image= models.ImageField(default = 'default.jpg', upload_to = 'profile_pics')
    def __str__(self):
        return f'Profile for { self.user.username }'

    def save(self, **kwargs):
        super().save()
        img = Image.open(self.image.path)
        if img.height > 300 or img.width > 300:
            output_size = (300, 300)
            img.thumbnail(output_size)
            img.save(self.image.path)