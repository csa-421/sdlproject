from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile
class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required = True)
    first_name = forms.CharField(max_length = 30)
    last_name = forms.CharField(max_length = 150)
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']
class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField(required = True)
    first_name = forms.CharField(max_length = 30)
    last_name = forms.CharField(max_length = 150)
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name']
class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = [
                'branch', 'phone_no', 'year_of_study', 'date_of_birth', 
                'has_driving_license', 'class_division', 'two_wheeler_no',
                'four_wheeler_no', 'gender', 'locality', 'image']

class DateInput(forms.DateInput):
    input_type = 'date'

class TimeInput(forms.TimeInput):
    input_type = 'time'

class ExampleForms(forms.Form):
    STATUS_CHOICES = (
    (1, ("Not relevant")),
    (2, ("Review")),
    (3, ("Maybe relevant")),
    (4, ("Relevant")),
    (5, ("Leading candidate")))
    RELEVANCE_CHOICES = (
    (1, ("Unread")),
    (2, ("Read")))
    my_date_field = forms.DateField(widget = DateInput)
    my_time_field = forms.TimeField(widget = TimeInput)
    choice_field = forms.ChoiceField(choices = STATUS_CHOICES, label="Choices", initial='', widget=forms.Select(), required=True)

class ExampleModelForm(forms.Form):
    class Meta:
        widgets = {'my_date_field' : DateInput,
                    'my_time_field' : TimeInput,
                   'choice_field' : forms.Select()}
