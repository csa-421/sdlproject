from django.db import models
from datetime import date
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
# Create your models here.
class OfferPost(models.Model):
    date_posted = models.DateTimeField(default = timezone.now)
    ride_date = models.DateField(db_column="my_date")
    instructions = models.TextField()
    ride_start_time = models.TimeField()
    ride_end_time = models.TimeField()
    ride_fees = models.IntegerField(default = 10)
    seats_available = models.IntegerField()
    ride_start_location = models.CharField(default = "Tathawade Chowk Bus Stop", max_length = 250)
    ride_end_location = models.CharField(default = "JSPM's RSCOE", max_length = 250)
    transport_mode = models.IntegerField(choices = ((1, ("Two Wheeler")),(2, ("Four Wheeler"))))
    author = models.ForeignKey(User, on_delete = models.CASCADE)    

    @property
    def my_date(self):
        return self._my_date

    @my_date.setter
    def my_date(self, value):
        if value < datetime.date.today():
            logger.warning("Date of Ride is incorrect...! Only Future rides are allowed..!")
        self._my_date = value
    def __str__(self):
        return f'{self.author.username} has posted'
    def get_absolute_url(self):
        return reverse('offerpost-detail', kwargs = {'pk' : self.pk})
    @property
    def is_dead(self):
        return date.today() > self.ride_date


class Ride(models.Model):
    ride_id = models.AutoField(primary_key = True)
    rider =  models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'rider')    
    pillion =   models.ForeignKey(User, on_delete = models.CASCADE, related_name = 'pillion')
    ride_status =  models.IntegerField(choices = ((1, ("Cancelled")),(2, ("Requested")),(3, ("Confirmed")), (4, ("Finished"))))
    related_ride_offer = models.ForeignKey(OfferPost, on_delete = models.CASCADE, related_name = 'related_ride_offer')   
    def __str__(self):
        return f'{self.rider.username} with {self.pillion.username}'

    @property
    def is_cancelled(self):
        return (self.ride_status == 1)
    @property
    def is_requested(self):
        return (self.ride_status == 2)
    @property
    def is_confirmed(self):
        return (self.ride_status == 3)
    @property
    def is_finished(self):
        return (self.ride_status == 4)
