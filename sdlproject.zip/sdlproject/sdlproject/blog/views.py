from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import OfferPost, Ride
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.mail  import send_mail
from django import forms
from .forms import OfferPostCreationForm, MailForms
from django.views.generic import DetailView, ListView, CreateView
from django.contrib.auth.decorators import login_required
from django.conf import settings
def home(request):
    context = {
        'offers': OfferPost.objects.all()
    }
    return render(request, 'blog/home.html', context)

def request_ride(request):
    #print(path)
    #print(type(path))
    p1 = path123.split('/')
    uid1 = int(p1[len(p1) - 2])
    obj = Ride(rider_id = OfferPost.objects.filter(id = uid1).first().author_id, pillion = request.user, ride_status = 2, related_ride_offer_id = uid1)
    obj.save()
    #print(int(p1[len(p1) - 2]))
    #print(type(int(p1[len(p1) - 2])))
    context = {
    'offers': OfferPost.objects.all()
    }
    return render(request, 'blog/home.html', context)

class OfferPostListView(ListView):
    model = OfferPost
    template_name = 'blog/home.html'
    context_object_name = 'offers'
    ordering = ['-date_posted']

class OfferPostDetailView(DetailView):
    model = OfferPost
    def get(self, request, *args, **kwargs):
        global path123
        path123 = request.path
        return render(request, 'blog/offerpost_detail.html')

class OfferPostCreateView(CreateView):
    model = OfferPost
    login_required = True
    form_class = OfferPostCreationForm
    def form_valid(self, form):
        form.instance.author = self.request.user
        form.instance.date_posted = timezone.now()
        return super().form_valid(form)

def about(request):
    return render(request, 'blog/about.html', { 'title' : 'a..bout'})
@login_required
def my_offers(request):
    if request.user.is_authenticated:
        current_user = request.user
        context = {
        'his_content': current_user.offerpost_set.all()
        }

    return render(request, 'blog/my_offers.html', context)

def front(request):
    return render(request, 'blog/A2.html')

def send_emails(request):    
    if request.method == 'POST':
        form = MailForms(request.POST)
        if form.is_valid():
            subject = form.cleaned_data.get('subject')
            message = form.cleaned_data.get('content')
            from_email = settings.EMAIL_HOST_USER
            
            to_list = [ settings.EMAIL_HOST_USER]
            for user in User.objects.all():
                to_list.append(user.email)
            send_mail(subject, message, from_email, to_list, fail_silently = True)


            messages.success(request, f'Dear Admin {request.user.username}! Mail Sent.')
            return redirect('blog-home')
    else:
        form = MailForms()
    return render(request, 'blog/send_mail.html', {'form':form})

def mainhome(request):
    return render(request, 'blog/mainhome.html')