from django.contrib import admin
from .models import OfferPost, Ride
# Register your models here.

admin.site.register(OfferPost)
admin.site.register(Ride)