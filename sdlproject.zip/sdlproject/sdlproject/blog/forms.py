from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import OfferPost, Ride

class DateInput(forms.DateInput):
    input_type = 'date'

class TimeInput(forms.TimeInput):
    input_type = 'time'

class OfferPostCreationForm(forms.ModelForm):
    ride_date = forms.DateField(widget = DateInput)
    instructions = forms.CharField(widget=forms.Textarea(attrs={"rows":5, "cols":20}))
    ride_start_time = forms.TimeField(widget = TimeInput)
    ride_end_time = forms.TimeField(widget = TimeInput)
    ride_fees = forms.IntegerField()
    seats_available = forms.IntegerField()
    ride_start_location = forms.CharField(max_length = 250)
    ride_end_location = forms.CharField(max_length = 250)
    RCHOICES = ((1, ("Two Wheeler")),(2, ("Four Wheeler")))
    transport_mode = forms.ChoiceField(choices = RCHOICES)
    #CHOICES = (
   # (1, ("YES")),
   # (2, ("NO")))
   # disclose_phone = forms.ChoiceField(choices = CHOICES, label = "Disclose Contact Number? ", initial='', widget=forms.Select(), required=True)
    class Meta:
        model = OfferPost
        fields = ['ride_date', 'instructions', 'ride_start_time', 'ride_end_time', 'seats_available', 'transport_mode', 'ride_start_location', 'ride_end_location', 'ride_fees']

class MailForms(forms.Form):
    subject = forms.CharField()
    content = forms.CharField(widget=forms.Textarea(attrs={"rows":5, "cols":20}))
