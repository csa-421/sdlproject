 
from django.urls import path
from .views import OfferPostDetailView, OfferPostListView, OfferPostCreateView
from django.contrib.auth.decorators import login_required

from . import views
urlpatterns = [
    path('', views.mainhome, name = 'blog-mainhome'),
    path('blog/', login_required(OfferPostListView.as_view()), name='blog-home'),
    path('offers/', views.my_offers, name = 'my_offers'),
    path('sendmail/', views.send_emails, name = 'send_mail'),
    path('requestride/', views.request_ride, name = 'request-ride'),
    path('offerpost/<int:pk>/', OfferPostDetailView.as_view(), name='offerpost-detail'),
    path('offerpost/new/', login_required(OfferPostCreateView.as_view()), name='offerpost-create'),
]